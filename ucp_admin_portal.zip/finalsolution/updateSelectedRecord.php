﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WAD Final Exam</title>
  <!-- BOOTSTRAP STYLES-->
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FONTAWESOME STYLES-->
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
  <!-- MORRIS CHART STYLES-->
  <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
  <!-- CUSTOM STYLES-->
  <link href="assets/css/custom.css" rel="stylesheet" />
  <!-- GOOGLE FONTS-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>

<body>
  <div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.html">UCP Portal</a>
      </div>
      <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
    </nav>
    <!-- /. NAV TOP  -->
    <nav class="navbar-default navbar-side" role="navigation">
      <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">
          <li class="text-center">
            <img src="assets/img/find_user.png" class="user-image img-responsive" />
          </li>
          <li>
            <a href="dashboard.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
          </li>
          <li>
            <a class="active-menu" href="update.php"><i class="fa fa-desktop fa-3x"></i> Update Student Record</a>
            <a href="delete.php"><i class="fa fa-desktop fa-3x"></i> Delete Student Record</a>
          </li>
      </div>

    </nav>
    <!-- /. NAV SIDE  -->


    <div id="page-wrapper">
      <div id="page-inner">
        <div class="row">
          <div class="col-md-12">
            <h2 class="text-center">Update Student Record</h2>

            <!-- your task is to connect it with db and initially catch the selected data from update.php page, and display here in the form. -->

            <?php
            // session_start();
            session_start();
            $id = $_POST["stdid"];
            $stdname = $_POST["stdname"];
            $stdemail = $_POST["stdemail"];
            $stdregnumber = $_POST["stdregnumber"];
            $stduniname = $_POST["stduniname"];
            //  $_SESSION["stdsearchdid"] = $id;
            //  $newid=$_SESSION["stdsearchdid"];
            

            echo "<form action='edit.php' method='POST'>

              <input type='text' class='form-control input-md' name='stdname' placeholder='Enter Name For Update' value='$stdname'/>
              <br>
              <input type='text' class='form-control input-md' name='stdemail' placeholder='Enter Email For Update' value='$stdemail'/>
              <br>
              <input type='text' class='form-control input-md' name='stdregnumber'
                placeholder='Enter Registration No For Update' value='$stdregnumber'/> 
                <br>
              <input type='text' class='form-control input-md' name='stduniname'
                placeholder='Enter University Name For Update' value='$stduniname'/> <br>
              <input type='submit' value='Update Record' class='btn btn-primary'>
              <input type='hidden' name='stdsearchdid' value='".$id."'>
            </form>";

            ?>

          </div>






        </div>
      </div>

    </div>
  </div>

  </div>

  </div>
  <!-- /. WRAPPER  -->
  <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
  <!-- JQUERY SCRIPTS -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- METISMENU SCRIPTS -->
  <script src="assets/js/jquery.metisMenu.js"></script>
  <!-- MORRIS CHART SCRIPTS -->
  <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
  <script src="assets/js/morris/morris.js"></script>
  <!-- CUSTOM SCRIPTS -->
  <script src="assets/js/custom.js"></script>


</body>

</html>