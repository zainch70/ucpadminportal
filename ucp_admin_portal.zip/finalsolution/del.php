<?php
$id=$_POST["stdid"];

$connection = new mysqli("localhost", "root", "", "final");
$q = "delete from stdinfo where id='$id'";
if($connection->query($q)==TRUE){
    header("location:delete.php");
    exit();
}
else{
    echo "Error Deleting Record";
}
?>