﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WAD Final Exam</title>
  <!-- BOOTSTRAP STYLES-->
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FONTAWESOME STYLES-->
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
  <!-- MORRIS CHART STYLES-->
  <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
  <!-- CUSTOM STYLES-->
  <link href="assets/css/custom.css" rel="stylesheet" />
  <!-- GOOGLE FONTS-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>

<body>
  <div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
      <div class="navbar-header">
        <a class="navbar-brand" href="dashboard.php">UCP Portal</a>
      </div>
      <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
    </nav>
    <!-- /. NAV TOP  -->
    <nav class="navbar-default navbar-side" role="navigation">
      <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">
          <li class="text-center">
            <img src="assets/img/find_user.png" class="user-image img-responsive" />
          </li>
          <li>
            <a href="dashboard.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
          </li>
          <li>
            <a class="active-menu" href="update.php"><i class="fa fa-desktop fa-3x"></i> Update Student Record</a>
            <a href="delete.php"><i class="fa fa-desktop fa-3x"></i> Delete Student Record</a>
          </li>
      </div>

    </nav>
    <!-- /. NAV SIDE  -->


    <div id="page-wrapper">
      <div id="page-inner">
        <div class="row">
          <div class="col-md-12">
            <h2 class="text-center">Update Student Record</h2>

            <!-- your task is to connect it with db and initially catch the data from input tag, and search the data in db -->
            <!-- if the data is avalible open the POPUP MODEL and display user's information -->
            <!-- User will change the info in MODEL and press Update button to update the record -->
            <!-- once record is updated, redirect the page to dashboard.php -->
            <form action="update.php" method="POST">

              <input type="text" class="search-query form-control input-md" name="stdregnumber"
                placeholder="Enter the registration number to search any student" /> <br>
              <center>
                <button type="submit" class="btn btn-default" data-toggle="modal" data-target="#myModal">Search</button>
              </center>
            </form>
          </div>

          <!--you will only display the relevant data inside the table, when user type any keyword in search bar, you will first
          check if that keyword found in db or not, if found then you will display the data in table, if not
          found then you will display "No Record Found" message in table -->

          <?php
            session_start();
            if (isset($_SESSION["email"])) {

          if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $stdregnumber = $_POST["stdregnumber"];
            $connection = new mysqli("localhost", "root", "", "final");
            $q = "select * from stdinfo where regnumber='$stdregnumber'";
            $result = $connection->query($q);

            if ($result->num_rows > 0) {
              echo "<div class='studentData'>";
              echo "
    <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
    <thead>
        <tr>
            <th>Student Name</th>
            <th>Email</th>
            <th>University Registration Number </th>
            <th>University Name</th>
            <th>Update</th>
        </tr>
    </thead>
    <tbody>";

              while ($row = $result->fetch_assoc()) {
                echo "  <tr>";
                echo "<td>".$row["name"]."</td>";
                echo "<td>".$row["email"]."</td>";
                echo "<td>".$row["regnumber"]."</td>";
                echo "<td>".$row["universityName"]."</td>";
                echo "<td>
                <form action='updateSelectedRecord.php' method='POST'>
                <input type='hidden' name='stdid' value='".$row["id"]."'>
                <input type='hidden' name='stdname' value='".$row["name"]."'>
                <input type='hidden' name='stdemail' value='".$row["email"]."'>
                <input type='hidden' name='stdregnumber' value='".$row["regnumber"]."'>
                <input type='hidden' name='stduniname' value='".$row["universityName"]."'>
                <input type='submit' value='Update' class='btn btn-primary'>
                </form>
                </td>";
                echo " </tr>";
              }
              echo "
     </tbody>
    </table>";
            }
            else{
              echo "<script>alert('Regestration Number Not Found');</script>";
            }
          }
        }else{
          header("location:index.php");
          exit();
        }
          ?>

        </div>
      </div>
    </div>

  </div>
  </div>

  </div>

  </div>
  <!-- /. WRAPPER  -->
  <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
  <!-- JQUERY SCRIPTS -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- METISMENU SCRIPTS -->
  <script src="assets/js/jquery.metisMenu.js"></script>
  <!-- MORRIS CHART SCRIPTS -->
  <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
  <script src="assets/js/morris/morris.js"></script>
  <!-- CUSTOM SCRIPTS -->
  <script src="assets/js/custom.js"></script>


</body>

</html>