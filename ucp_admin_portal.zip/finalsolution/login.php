<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stdemail = $_POST["stdemail"];
    $stdpassword = $_POST["stdpassword"];

    $connection = new mysqli("localhost", "root", "", "final");
    $q = "select * from stdinfo where email='$stdemail' and password='$stdpassword'";
    $result = $connection->query($q);
    $row = $result->fetch_assoc();

    if ($result->num_rows > 0) {
        session_start();

        $_SESSION["id"] = $row["id"];
        $_SESSION["name"] = $row["name"];
        $_SESSION["email"] = $row["email"];
        $_SESSION["age"] = $row["age"];
        $_SESSION["regnumber"] = $row["regnumber"];
        $_SESSION["universityName"] = $row["universityName"];
        $_SESSION["password"] = $row["password"];

        if (isset($_SESSION["email"])) {
            header("location:dashboard.php");
            exit();
        } else {
            header("location:index.php");
            exit();
        }

    } else {
        echo "<script>alertbox('Plz Enter valid email and password');</script>";
        header("location:index.php");
        exit();
    }
}
else {
    echo "<script>alertbox('Plz Enter valid email and password');</script>";
    header("location:index.php");
    exit();
}
?>