<?php
    $stdname=$_POST["stdname"];
    $stdemail=$_POST["stdemail"];
    $stdregnumber=$_POST["stdregnumber"];
    $stduniname=$_POST["stduniname"];
    $stdsearchdid=$_POST["stdsearchdid"];
    
    $connection = new mysqli("localhost", "root", "", "final");
    $q = "update stdinfo set name='$stdname',email='$stdemail',regnumber='$stdregnumber',universityName='$stduniname' where id='$stdsearchdid'";

    if($connection->query($q)===TRUE){
      header("location:update.php");
      exit();
    }
    else{
      echo "Error Updating Record";
    }
?>