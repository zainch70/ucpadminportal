<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <style>
    .text-link {
      color: #007bff; /* Bootstrap primary color */
      text-decoration: none;
    }

    .text-link:hover {
      text-decoration: underline;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f8f9fa;
    }

    .form-container {
      background-color: #ffffff;
      padding: 2rem;
      border-radius: 0.25rem;
      box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
      width: 100%;
      max-width: 400px;
    }

    .header img {
      max-width: 150px;
      margin-bottom: 1rem;
    }

    .login-form .title {
      font-size: 1.5rem;
      font-weight: 600;
      margin-bottom: 1rem;
    }
  </style>
</head>

<body>
  <?php
  // Check if the form is submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stdname = $_POST["stdname"];
    $stdemail = $_POST["stdemail"];
    $stdage = $_POST["stdage"];
    $stdregnumber = $_POST["stdregnumber"];
    $stduni = $_POST["stduni"];
    $stdpassword = $_POST["stdpassword"];

    // Connect to the database
    $connection = new mysqli("localhost", "root", "", "final");

    // Check if email or registration number already exists
    $q1 = "SELECT * FROM stdinfo WHERE email='$stdemail' OR regnumber='$stdregnumber'";
    $res2 = $connection->query($q1);
    if ($res2->num_rows > 0) {
      echo "<script>alert('Username Already Exists')</script>";
    } else {
      // Insert new user data
      $q = "INSERT INTO stdinfo (name, email, age, regnumber, universityname, password) VALUES ('$stdname', '$stdemail', '$stdage', '$stdregnumber', '$stduni', '$stdpassword')";
      if ($connection->query($q) === TRUE) {
        header("Location: index.php");
        exit();
      } else {
        echo "ERROR Signup";
      }
    }
  }
  ?>

  <div class="container">
    <div class="form-container">
      <div class="header text-center">
        <img src="assets/logo.png" alt="Logo" />
      </div>
      <div class="login-form">
        <div class="title text-center">Login</div>
        <form action="login.php" method="POST">
          <div class="form-group">
            <label for="email">Email</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
              </div>
              <input type="text" id="email" name="stdemail" class="form-control" placeholder="Enter your email" required />
            </div>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
              </div>
              <input type="password" id="password" name="stdpassword" class="form-control" placeholder="Enter your password" required />
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-block">Submit</button>
          <div class="text-center mt-3">
            Don't have an account? <a href="signup.php" class="text-link">Signup Now</a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
