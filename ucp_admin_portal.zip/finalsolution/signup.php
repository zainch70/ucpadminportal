<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup Form</title>
  <link rel="stylesheet" href="assets/loginstyle.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <style>
    body {
      background-color: #f3f4f6;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .signup-form {
      background-color: #ffffff;
      padding: 2rem;
      border-radius: 0.5rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
    }

    .title {
      font-size: 1.5rem;
      font-weight: bold;
      color: #333;
      margin-bottom: 1.5rem;
      text-align: center;
    }

    .input-boxes {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .input-box {
      display: flex;
      align-items: center;
      border: 1px solid #ddd;
      border-radius: 0.25rem;
      padding: 0.5rem;
      background-color: #fafafa;
    }

    .input-box i {
      color: #888;
      margin-right: 0.5rem;
    }

    .input-box input {
      border: none;
      outline: none;
      background: transparent;
      flex: 1;
    }

    .button {
      text-align: center;
    }

    .button input {
      background-color: #1d4ed8;
      color: #ffffff;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 0.25rem;
      cursor: pointer;
      font-size: 1rem;
      font-weight: bold;
      transition: background-color 0.3s;
    }

    .button input:hover {
      background-color: #1e40af;
    }

    .sign-up-text {
      text-align: center;
      margin-top: 1rem;
    }

    .sign-up-text a {
      color: #1d4ed8;
      text-decoration: none;
    }

    .sign-up-text a:hover {
      text-decoration: underline;
    }

    @media (max-width: 600px) {
      .signup-form {
        padding: 1rem;
      }

      .title {
        font-size: 1.25rem;
      }
    }
  </style>
</head>

<body>
  <div class="signup-form">
    <div class="title">Signup</div>

    <form action="index.php" method="POST">
      <div class="input-boxes">
        <div class="input-box">
          <i class="fas fa-user"></i>
          <input type="text" name="stdname" placeholder="Enter your name" required />
        </div>
        <div class="input-box">
          <i class="fas fa-envelope"></i>
          <input type="text" name="stdemail" placeholder="Enter your email" required />
        </div>
        <div class="input-box">
          <i class="fas fa-calendar"></i>
          <input type="text" name="stdage" placeholder="Enter your age" required />
        </div>
        <div class="input-box">
          <i class="fas fa-calendar"></i>
          <input type="text" name="stdregnumber" placeholder="Enter Registration Number" required />
        </div>
        <div class="input-box">
          <i class="fas fa-user"></i>
          <input type="text" name="stduni" placeholder="Enter your University Name" required />
        </div>
        <div class="input-box">
          <i class="fas fa-lock"></i>
          <input type="password" name="stdpassword" placeholder="Enter your password" required />
        </div>
        <div class="button input-box">
          <input type="submit" value="Submit" />
        </div>
        <div class="text sign-up-text">
          Already have an account? <a href="index.php" id="anchor">Login now</a>
        </div>
      </div>
    </form>
  </div>
</body>

</html>
